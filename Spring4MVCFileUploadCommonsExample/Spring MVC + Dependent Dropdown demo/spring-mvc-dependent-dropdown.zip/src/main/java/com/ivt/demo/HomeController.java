package com.ivt.demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;

@Controller
@RequestMapping(value = "/")
public class HomeController {
    //http://plugins.krajee.com/dependent-dropdown/demo

    @RequestMapping(method = GET)
    public String home() {
        return "home";
    }

    @RequestMapping(value = "/subCategory", method = POST)
    @ResponseBody
    public Object subCategory(HttpServletRequest request) throws InterruptedException {
        Thread.sleep(5000); // simulate a long processing...
        String selected = request.getParameter("depdrop_parents[0]");
        if ("Electronics".equals(selected)){
            String jsonOutput = "{\n" +
                    "    \"output\": [\n" +
                    "        {\"id\": \"1\", \"name\": \"Camera\"},\n" +
                    "        {\"id\": \"2\", \"name\": \"Television\"}\n" +
                    "    ],\n" +
                    "    \"selected\": \"1\"\n" +
                    "}";
            return jsonOutput;
        } else {
            String jsonOutput = "{\n" +
                    "    \"output\": [\n" +
                    "        {\"id\": \"3\", \"name\": \"Ebooks\"},\n" +
                    "        {\"id\": \"4\", \"name\": \"Music\"}\n" +
                    "    ],\n" +
                    "    \"selected\": \"1\"\n" +
                    "}";
            return jsonOutput;
        }

    }
}
