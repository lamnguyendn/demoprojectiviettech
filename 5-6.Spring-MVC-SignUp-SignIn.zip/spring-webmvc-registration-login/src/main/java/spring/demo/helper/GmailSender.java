package spring.demo.helper;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.UnsupportedEncodingException;
import java.util.Properties;

/**
 * Created by vhphat on 10/8/2016.
 */
public class GmailSender {
    private static String SENDER_EMAIL = "conos.team@gmail.com";
    private static String SENDER_EMAIL_PWD = "axoninsight123";

    public static void send(String to, String subject, String body, boolean bodyIsHTML)
            throws MessagingException, UnsupportedEncodingException {
        //1 - Get an email session
        Properties props = new Properties();
        props.put("mail.transport.protocol", "smtps");
        props.put("mail.smtps.host", "smtp.gmail.com");
        props.put("mail.smtps.port", 465);
        props.put("mail.smtps.auth", "true");
        props.put("mail.smtps.quitwait", "false");
        Session session = Session.getDefaultInstance(props);
        session.setDebug(true);

        //2 - Create a message
        Message message = new MimeMessage(session);
        message.setSubject(subject);
        if (bodyIsHTML) {
            message.setContent(body, "text/html");
        } else {
            message.setText(body);
        }

        // 3 - address the message
        Address fromAddress = new InternetAddress(SENDER_EMAIL, "iViettech");
        Address toAddress = new InternetAddress(to);
        message.setFrom(fromAddress);
        message.setRecipient(Message.RecipientType.TO, toAddress);

        // 4 - send the message
        Transport transport = session.getTransport();
        transport.connect(SENDER_EMAIL, SENDER_EMAIL_PWD);
        transport.sendMessage(message, message.getAllRecipients());
        transport.close();
    }
}
