package com.ivt.googlemapdemo;

/**
 * Created by vhphat on 8/20/2016.
 */
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping(value = "/")
public class MapController {
    @RequestMapping(method = RequestMethod.GET)
    public String showMap(Model model) {
        model.addAttribute("location", new Location(16.074559, 108.218463));
        return "index";
    }
}
