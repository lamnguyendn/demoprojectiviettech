package com.ivt.seatingmap.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;

import java.util.ArrayList;
import java.util.List;

import static org.springframework.web.bind.annotation.RequestMethod.*;
/**
 * Created by vhphat on 12/2/2016.
 */
@Controller
@RequestMapping(value = "/")
public class HomeController {
    // reference: https://github.com/mateuszmarkowski/jQuery-Seat-Charts
    @RequestMapping(method = GET)
    public String home(Model model) {
        String alreadyBookedList = "1_1,4_2,7_1,7_2";
        model.addAttribute("alreadyBookedList", alreadyBookedList);
        return "home";
    }

    @RequestMapping(value = "/checkout", method = POST)
    public String checkout(HttpServletRequest request, Model model) {
        String selectedSeats = request.getParameter("selectedSeats");
        //selectedSeats data example: 15-40,16-40 -> 2 seats: 15 (40$), 16(40$)
        selectedSeats = selectedSeats.substring(0, selectedSeats.length() - 1);
        String[] seatsArr = selectedSeats.split(",");
        List<Seat> seatList = new ArrayList<>();
        for (int i = 0; i< seatsArr.length; i++) {
            String[] seat = seatsArr[i].split("-");
            seatList.add(new Seat(seat[0], seat[1]));
        }
        model.addAttribute("seatList", seatList);

        return "checkout";
    }
}
