package com.ivt.seatingmap.controller;

/**
 * Created by vhphat on 12/2/2016.
 */
public class Seat {
    private int number;
    private double price;

    public Seat() {
    }

    public Seat(String number, String price) {
        this.number = Integer.valueOf(number);
        this.price = Double.valueOf(price);
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}
