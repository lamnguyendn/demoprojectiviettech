package com.ivt.datatables.controller;


import com.ivt.datatables.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import static org.springframework.web.bind.annotation.RequestMethod.GET;

@Controller
@RequestMapping(value = "/")
public class HomeController {
    // https://datatables.net/
    @Autowired
    BookRepository bookRepository;

    @RequestMapping(method = GET)
    public String showBooks(Model model) {
        model.addAttribute("bookList", bookRepository.getBooks());
        return "home";
    }
}
