package com.ivt.datatables.repository;

import com.ivt.datatables.entity.BookEntity;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;

@Repository
public class BookRepository {
    private List<BookEntity> bookEntityList;

    @PostConstruct
    public void init(){
        bookEntityList = new ArrayList<BookEntity>(){{
            for(int i = 1; i<=100; i++) {
                add(new BookEntity(i, "Java A-Z, chapter " + i, "Author_" + i, 12 + i, "3-12-675495-" + i));
            }
        }};
    }

    public List<BookEntity> getBooks(){
        return bookEntityList;
    }
}
