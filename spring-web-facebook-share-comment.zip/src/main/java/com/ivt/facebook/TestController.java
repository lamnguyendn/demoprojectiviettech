package com.ivt.facebook;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Created by vhphat on 11/22/2016.
 */
@Controller
@RequestMapping(value = "/")
public class TestController {
    @RequestMapping(method = RequestMethod.GET)
    public String show(Model model) {
        //model.addAttribute("location", new Location(16.074559, 108.218463));
        return "index";
    }
}
