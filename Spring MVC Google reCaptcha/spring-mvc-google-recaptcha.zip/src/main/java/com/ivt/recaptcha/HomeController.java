package com.ivt.recaptcha;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;

import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;

@Controller
@RequestMapping(value = "/")
public class HomeController {

    @RequestMapping(method = GET)
    public String showHome(Model model) {
        model.addAttribute("user", new User());
        return "index";
    }

    @RequestMapping(value = "doRegister", method = POST)
    public String doRegister(Model model, User user, HttpServletRequest request) {
        System.out.println(user.getUsername());
        boolean captchaOK = GoogleRecaptchaVerify.verify(request.getParameter("g-recaptcha-response"));
        if (captchaOK) {
            model.addAttribute("username", user.getUsername());
            return "home";
        }
        model.addAttribute("error", "Please verify the captcha");
        return "index";
    }
}
