package com.ivt.websocket;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by vhphat on 11/25/2016.
 */
@Controller
@RequestMapping(value = "admin")
public class AdminController {
    List<Book> bookList = new ArrayList<>();

    @Autowired
    private SimpMessagingTemplate template;

    @RequestMapping(method = RequestMethod.GET)
    public String home() {
        return "admin";
    }

    @MessageMapping("/addBook")
    public void addBook(Book book) throws Exception {
        bookList.add(book);
        template.convertAndSend("/book/bookList", bookList);
    }
}
