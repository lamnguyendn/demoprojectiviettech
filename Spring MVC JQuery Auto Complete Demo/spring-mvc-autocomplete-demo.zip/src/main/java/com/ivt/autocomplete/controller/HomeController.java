package com.ivt.autocomplete.controller;

import com.ivt.autocomplete.entity.BookEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by vhphat on 11/25/2016.
 */
@Controller
@RequestMapping(value = "/")
public class HomeController {
    List<BookEntity> bookList = new ArrayList<>();

    @PostConstruct
    public void init(){
        bookList.add(new BookEntity(1, "Java A-Z"));
        bookList.add(new BookEntity(2, "Linux Shell programming"));
        bookList.add(new BookEntity(3, "PHP A-Z"));
        bookList.add(new BookEntity(4, "Net programming"));
    }
    @RequestMapping(method = RequestMethod.GET)
    public String showMap() {
        return "index";
    }



    @RequestMapping(value = "/getBooks", method = RequestMethod.GET)
    @ResponseBody
    public List<BookEntity> getBooks(@RequestParam String bookName) {
        List<BookEntity> result = new ArrayList<>();
        for(BookEntity bookEntity : bookList) {
            if (bookEntity.getName().contains(bookName)) {
                result.add(bookEntity);
            }
        }
        return result;

    }
}
