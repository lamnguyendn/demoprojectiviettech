jQuery(document).ready(function($) {
    $("#submitCommentForm").submit(function(event) {
        // Prevent the form from submitting via the browser.
        event.preventDefault();
        submitComment();
    });
});

function submitComment() {
    var comment = $("#username").val() + "," + $("#content").val();

    $.ajax({
        type : "POST",
        contentType : "application/json",
        url : "/comment/submit",
        data : comment,
        timeout : 100000,
        success : function(data) {
            console.log(data);
            display(data);
        }
    });
}

function display(data) {
    var comment = data.split('||');
    var newComment = "<div class='form-group'>"
                            + "<label>" +comment[0] + "</label>"
                            + "<input type='text' class='form-control' placeholder='" + comment[1] + "' readonly>"
                    + "</div>";
    $('#commentList').append(newComment);
}