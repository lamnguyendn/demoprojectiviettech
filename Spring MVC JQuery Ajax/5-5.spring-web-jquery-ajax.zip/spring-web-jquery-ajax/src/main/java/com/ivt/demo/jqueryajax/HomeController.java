package com.ivt.demo.jqueryajax;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping(value = "/")
public class HomeController {
    @RequestMapping(method = RequestMethod.GET)
    public String showMap(Model model) {
        model.addAttribute("comment", new Comment());
        return "index";
    }

    @RequestMapping(method = RequestMethod.POST, value = "/comment/submit", produces = "text/plain;charset=UTF-8")
    @ResponseBody
    public String submitComment(@RequestBody String body) {
        String[] commentArr = body.split(",");
        Comment comment = new Comment(commentArr[0], commentArr[1]);
        // save comment to DB
        return comment.getUsername() + "||" + comment.getContent();
    }
}
